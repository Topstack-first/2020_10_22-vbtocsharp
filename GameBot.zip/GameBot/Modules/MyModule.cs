﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GameBot.Modules
{
    class MyModule
    {
        public static string loginUrl;
    }
}

﻿using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Reflection.Metadata.Ecma335;
using System.Security.Policy;
using System.Text;
using System.Windows.Forms;

namespace GameBot.Modules
{
    public class MyNLGames
    {
        public static mainform main_form;

        private IWebDriver webDriver;
        
        public string myMobileNo;
        public string myPassword;
        internal string myWebsiteUrl;
        private ReadOnlyCollection<IWebElement> tags1;

        public MyNLGames(mainform frm)
        {
            webDriver = new ChromeDriver();
            main_form = frm;
        }

        public void closeDriver()
        {
            webDriver.Quit();
        }

        public void runNLGamesProcess(string myGame)
        {
            main_form.setStatus("Opening " + myGame + " file...");

        }

        [Obsolete]
        internal void removeAllTickets()
        {
            if(myMobileNo != "" && myPassword != "")
            {
                main_form.setStatus("Loading website...");
                Login(myMobileNo, myPassword);
                main_form.setStatus("Opening cart page to remove tickets...");
                if(myWebsiteUrl != "")
                {
                    webDriver.Navigate().GoToUrl(myWebsiteUrl);
                    tags1 = webDriver.FindElements(By.ClassName("removeTicket"));
                    foreach(IWebElement tag in tags1)
                    {
                        var wait = new WebDriverWait(webDriver, TimeSpan.FromSeconds(2000));
                        setFocus(tag);
                        tag.Click();
                        wait.Until(ExpectedConditions.StalenessOf(tag));//wait for page load
                        closePopup("error_popup");
                    }
                }
            }
            main_form.setStatus("Ready");
        }

        private void closePopup(string myID)
        {
            main_form.setStatus("Checking for a popup...");
            IWebElement obj, tag;
            if(webDriver.FindElement(By.Id(myID)) != null)
            {
                obj = webDriver.FindElement(By.Id(myID));
                tag = webDriver.FindElement(By.TagName("a"));
                if(tag != null)
                {
                    if (tag.Displayed)
                        tag.Click();
                }

            }
        }

        private void setFocus(IWebElement tag)
        {
        }

        private void doNLGamesLogin()
        {
            MyBrowser.loadWebpageSource(MyModule.loginUrl);
        }

        internal bool isNLGamesLogin()
        {
            return false;
        }

        [Obsolete]
        public void Login(string username, string password)
        {
            // Navigate to url
            webDriver.Url = MyModule.loginUrl;

            // Find the username field (Facebook calls it "email") and enter value
            var input = webDriver.FindElement(By.Id("userName_email"));
            input.SendKeys(username);

            // Find the password field and enter value
            input = webDriver.FindElement(By.Id("password"));
            input.SendKeys(password);

            // Click on the login button
            ClickAndWaitForPageToLoad(webDriver, By.Id("loginbutton"));

            // At this point, site will launch a post-login "wizard" that will 
            // keep asking unknown amount of questions (it thinks it's the first time 
            // you logged in using this computer). We'll just click on the "continue" 
            // button until they give up and redirect us to our "wall".
            try
            {
                while (webDriver.FindElement(By.Id("checkpointSubmitButton")) != null)
                {
                    // Clicking "continue" until we're done
                    ClickAndWaitForPageToLoad(webDriver, By.Id("checkpointSubmitButton"));
                }
            }
            catch
            {
                // We will try to click on the next button until it's not there or we fail.
                // site is unexpected as to what will happen, but this approach seems 
                // to be pretty reliable
            }
        }

        [Obsolete]
        private void ClickAndWaitForPageToLoad(IWebDriver driver,
            By elementLocator, int timeout = 10)
        {
            try
            {
                var wait = new WebDriverWait(driver, TimeSpan.FromSeconds(timeout));
                var elements = driver.FindElements(elementLocator);
                if (elements.Count == 0)
                {
                    throw new NoSuchElementException(
                        "No elements " + elementLocator + " ClickAndWaitForPageToLoad");
                }
                var element = elements.FirstOrDefault(e => e.Displayed);
                element.Click();
                wait.Until(ExpectedConditions.StalenessOf(element));
            }
            catch (NoSuchElementException)
            {
                Console.WriteLine(
                    "Element with locator: '" + elementLocator + "' was not found.");
                throw;
            }
        }
    }
}

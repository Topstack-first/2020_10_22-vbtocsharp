﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using GameBot.Modules;
using Microsoft.Win32;

namespace GameBot
{
    public partial class mainform : Form
    {
        string libDir;
        string myINIFileNameWithDirPath;
        private string dataDir;
        private string sURL;
        private string mainURL;
        private string myWebsiteURL;
        
        private string gameUrl;
        private string localTxtFile;
        private string strData;
        Boolean createLog;
        string logFile;
        private string receiptDir;
        string gameFile;
        public static MyNLGames myNLGames;

        public mainform()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            MessageBox.Show("button clicked!");
        }

        private void mainform_KeyPress(object sender, KeyPressEventArgs e)
        {
            //not working yet...
            MessageBox.Show("pressed " + e.KeyChar);
        }

        private void mainform_Load(object sender, EventArgs e)
        {
            string xlPath, time1, xloutPath, keywords;

            myNLGames = new MyNLGames(this);

            tabControl1.SelectTab(0);
            libDir = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData) + @"\" + System.AppDomain.CurrentDomain.FriendlyName;
            System.IO.Directory.CreateDirectory(libDir);
            myINIFileNameWithDirPath = libDir + @"\Settings.ini";

            dataDir = libDir + @"\Data";
            gameFile = dataDir + @"\Lotto.txt";
            System.IO.Directory.CreateDirectory(dataDir);

            receiptDir = libDir + @"\Receipts";
            System.IO.Directory.CreateDirectory(receiptDir);

            loadCmbGameWebsiteWager();

            loadCmbGameNL();

            loadCmbColumnNL();

            loadCmbGameHB();

            myWebsiteURL = "https://www.nationallottery.co.za";
            MyModule.loginUrl = myWebsiteURL;
            gameUrl = myWebsiteURL + "/play-now/lotto";

            loadGameSettings();

            loadReceipts(listViewNL, receiptDir + @"\nlReceipt");
            loadReceipts(listViewHB, receiptDir + @"\hbReceipt");


            toolStripStatusLabel1.Text = "Ready";
        }

        private void loadCmbGameHB()
        {
            ComboBoxItem item = new ComboBoxItem();
            item = new ComboBoxItem();
            item.Text = "SA Lotto Draw";
            item.Value = 2456158;
            cmbGameHB.Items.Add(item);

            item = new ComboBoxItem();
            item.Text = "SA Daily Lotto";
            item.Value = 2486402;
            cmbGameHB.Items.Add(item);

            item = new ComboBoxItem();
            item.Text = "SA Powa Numbas";
            item.Value = 2432979;
            cmbGameHB.Items.Add(item);
        }

        private void loadCmbColumnNL()
        {
            ComboBoxItem item = new ComboBoxItem();

            item.Text = "Choose 2 Numbers";
            item.Value = 2;
            cmbColumnNL.Items.Add(item);

            item.Text = "Choose 3 Numbers";
            item.Value = 3;
            cmbColumnNL.Items.Add(item);

            item.Text = "Choose 4 Numbers";
            item.Value = 4;
            cmbColumnNL.Items.Add(item);

            item.Text = "Choose 5 Numbers";
            item.Value = 5;
            cmbColumnNL.Items.Add(item);

            item.Text = "Choose 6 Numbers + 1 Power";
            item.Value = 6;
            cmbColumnNL.Items.Add(item);

            item.Text = "Choose 2 Numbers + 1 Power";
            item.Value = 3;
            cmbColumnNL.Items.Add(item);

            item.Text = "Choose 3 Numbers + 1 Power";
            item.Value = 4;
            cmbColumnNL.Items.Add(item);

            item.Text = "Choose 4 Numbers + 1 Power";
            item.Value = 5;
            cmbColumnNL.Items.Add(item);

            item.Text = "Choose 5 Numbers + 1 Power";
            item.Value = 6;
            cmbColumnNL.Items.Add(item);
        }

        private void loadCmbGameNL()
        {
            cmbGameNL.Items.Add("Lotto");
            cmbGameNL.Items.Add("Daily Lotto");
            cmbGameNL.Items.Add("PowerBall");
        }

        private void loadCmbGameWebsiteWager()
        {
            cmbGameWebsiteWager.Items.Add("https://www.nationallottery.co.za");
            cmbGameWebsiteWager.Items.Add("https://www.hollywoodbets.net");
        }

        void loadReceipts(ListView list, string path)
        {
            list.Items.Clear();
            string[] files = Directory.GetFiles(path);
            foreach (string file in files)
                list.Items.Add(Path.GetFileNameWithoutExtension(file));
        }

        void loadColumnHB(int opt)
        {
            cmbColumnHB.Items.Clear();
            ComboBoxItem item = new ComboBoxItem();

            if (opt == 0)
            {
                item = new ComboBoxItem("1 Ball (Main Set & Bonus)", 1);
                cmbColumnHB.Items.Add(item);

                item = new ComboBoxItem();
                item.Text = "1 Ball (Bonus)";
                item.Value = 1;
                cmbColumnHB.Items.Add(item);

                item = new ComboBoxItem();
                item.Text = "2 Balls (Main Set & Bonus)";
                item.Value = 2;
                cmbColumnHB.Items.Add(item);

                item = new ComboBoxItem();
                item.Text = "3 Balls (Main Set & Bonus)";
                item.Value = 3;
                cmbColumnHB.Items.Add(item);

                item = new ComboBoxItem();
                item.Text = "4 Balls (Main Set & Bonus)";
                item.Value = 4;
                cmbColumnHB.Items.Add(item);

                item = new ComboBoxItem();
                item.Text = "5 Balls (Main Set & Bonus)";
                item.Value = 5;
                cmbColumnHB.Items.Add(item);
            }
            else if(opt == 1)
            {
                item = new ComboBoxItem();
                item.Text = "1 Ball (Main Set)";
                item.Value = 1;
                cmbColumnHB.Items.Add(item);

                item = new ComboBoxItem();
                item.Text = "2 Balls (Main Set)";
                item.Value = 2;
                cmbColumnHB.Items.Add(item);

                item = new ComboBoxItem();
                item.Text = "3 Balls (Main Set)";
                item.Value = 3;
                cmbColumnHB.Items.Add(item);

                item = new ComboBoxItem();
                item.Text = "4 Balls (Main Set)";
                item.Value = 4;
                cmbColumnHB.Items.Add(item);
            }
            else if(opt == 2)
            {
                item = new ComboBoxItem();
                item.Text = "2 Balls (2 Main Set)";
                item.Value = 2;
                cmbColumnHB.Items.Add(item);

                item = new ComboBoxItem();
                item.Text = "2 Balls (2 Main Set)";
                item.Value = 2;
                cmbColumnHB.Items.Add(item);

                item = new ComboBoxItem();
                item.Text = "2 Balls (1 Main Set & 1 Bonus)";
                item.Value = 2;
                cmbColumnHB.Items.Add(item);

                item = new ComboBoxItem();
                item.Text = "3 Balls (3 Main Set)";
                item.Value = 3;
                cmbColumnHB.Items.Add(item);

                item = new ComboBoxItem();
                item.Text = "3 Balls (2 Main Set & 1 Bonus)";
                item.Value = 3;
                cmbColumnHB.Items.Add(item);

                item = new ComboBoxItem();
                item.Text = "4 Balls (4 Main Set)";
                item.Value = 4;
                cmbColumnHB.Items.Add(item);

                item = new ComboBoxItem();
                item.Text = "4 Balls (3 Main Set & 1 Bonus)";
                item.Value = 4;
                cmbColumnHB.Items.Add(item);

                item = new ComboBoxItem();
                item.Text = "4 Balls (Main Set)";
                item.Value = 5;
                cmbColumnHB.Items.Add(item);
            }
            cmbColumnHB.SelectedIndex = 0;

        }

        public void saveGameSettings()
        {
            RegistryKey key = Registry.CurrentUser.CreateSubKey(@"SOFTWARE\GameBotSettings");

            //storing the values  
            key.SetValue("Setting_website", cmbGameWebsiteWager.SelectedIndex);

            key.SetValue("Setting1_Mobile", txtMobileNoNL.Text);
            key.SetValue("Setting1_Pin", txtPinNL.Text);
            key.SetValue("Setting1_column", cmbColumnNL.SelectedIndex);
            key.SetValue("Setting1_game", cmbGameNL.SelectedIndex);
            key.SetValue("Setting1_payFromMyWallet", chkPayWalletNL.Checked?1:0);
            key.SetValue("Setting1_lottoPlus1", chkLottoPlus1.Checked?1:0);
            key.SetValue("Setting1_lottoPlus2", chkLottoPlus2.Checked?1:0);
            key.SetValue("Setting1_powerBallPlus", chkPowerBallPlus.Checked?1:0);

            key.SetValue("Setting2_Username", txtUsernameHB.Text);
            key.SetValue("Setting2_Password", txtPasswordHB.Text);
            key.SetValue("Setting2_column", cmbColumnHB.SelectedIndex);
            key.SetValue("Setting2_game", cmbGameHB.SelectedIndex);
            key.SetValue("Setting2_betAmount", txtBetAmountHB.Text);

            key.Close();


        }

        public void saveDefaultGameSettings()
        {
            RegistryKey key = Registry.CurrentUser.CreateSubKey(@"SOFTWARE\GameBotSettings");

            //storing the values  
            key.SetValue("Setting_website", 1);

            key.SetValue("Setting1_Mobile", 0793742001);
            key.SetValue("Setting1_Pin", "7?<?8");
            key.SetValue("Setting1_column", 3);
            key.SetValue("Setting1_game", 1);
            key.SetValue("Setting1_payFromMyWallet", 1);
            key.SetValue("Setting1_lottoPlus1", 1);
            key.SetValue("Setting1_lottoPlus2", 0);

            key.SetValue("Setting1_powerBallPlus", 1);
            key.SetValue("Setting2_Username", "kmolefe69@me.com");
            key.SetValue("Setting2_Password", "7?<?");
            key.SetValue("Setting2_column", 6);
            key.SetValue("Setting2_game", 2);
            key.SetValue("Setting2_betAmount", 1);

            key.Close();
        }

        public void loadGameSettings()
        {
            RegistryKey key = Registry.CurrentUser.OpenSubKey(@"SOFTWARE\GameBotSettings");

            if(key == null)
            {
                saveDefaultGameSettings();
                key = Registry.CurrentUser.OpenSubKey(@"SOFTWARE\GameBotSettings");
            }

            cmbGameWebsiteWager.SelectedIndex = Convert.ToInt32( key.GetValue("Setting_website"));
            txtMobileNoNL.Text = Convert.ToString(key.GetValue("Setting1_Mobile"));
            txtPinNL.Text = Convert.ToString(key.GetValue("Setting1_Pin"));
            cmbColumnNL.SelectedIndex = Convert.ToInt32(key.GetValue("Setting1_column"));
            cmbGameNL.SelectedIndex = Convert.ToInt32(key.GetValue("Setting1_game"));
            txtBetAmountHB.Text = Convert.ToString(key.GetValue("Setting2_betAmount"));
            chkPayWalletNL.Checked = Convert.ToBoolean(Convert.ToInt32(key.GetValue("Setting2_betAmount")));
            chkLottoPlus1.Checked = Convert.ToBoolean(Convert.ToInt32(key.GetValue("Setting1_lottoPlus1")));
            chkLottoPlus2.Checked = Convert.ToBoolean(Convert.ToInt32(key.GetValue("Setting1_lottoPlus2")));
            chkPowerBallPlus.Checked = Convert.ToBoolean(Convert.ToInt32(key.GetValue("Setting1_powerBallPlus")));
            txtUsernameHB.Text = Convert.ToString(key.GetValue("Setting2_Username"));
            txtPasswordHB.Text = Convert.ToString(key.GetValue("Setting2_Password"));
            cmbGameHB.SelectedIndex = Convert.ToInt32(key.GetValue("Setting2_game"));
            
            loadColumnHB(cmbGameHB.SelectedIndex);

            cmbColumnHB.SelectedIndex = Convert.ToInt32(key.GetValue("Setting2_column"));
            txtBetAmountHB.Text = Convert.ToString(key.GetValue("Setting2_betAmount"));


        }

        private void cmbGameHB_Click(object sender, EventArgs e)
        {
            loadColumnHB(cmbGameHB.SelectedIndex);
        }

        private void mainform_FormClosing(object sender, FormClosingEventArgs e)
        {
            saveGameSettings();
            myNLGames.closeDriver();
        }

        private void cmbGameHB_SelectedIndexChanged(object sender, EventArgs e)
        {
            gameFile = dataDir + @"\" + cmbGameHB.Text + ".txt";
        }

        private void cmbGameNL_SelectedIndexChanged(object sender, EventArgs e)
        {
            gameFile = dataDir + @"\" + cmbGameNL.Text + ".txt";
            chkLottoPlus1.Visible = false;
            chkLottoPlus2.Visible = false;
            chkPowerBallPlus.Visible = false;

            if(cmbGameNL.SelectedIndex == 0)
            {
                chkLottoPlus1.Visible = true;
                chkLottoPlus2.Visible = true;
                gameUrl = myWebsiteURL + @"/play-now/lotto";
            }
            else if(cmbGameNL.SelectedIndex == 1)
            {
                gameUrl = myWebsiteURL + @"/play-now/daily-lotto";
            }
            else if(cmbGameNL.SelectedIndex == 2)
            {
                chkPowerBallPlus.Visible = true;
                gameUrl = myWebsiteURL + @"/play-now/powerball";
            }
        }

        private void btnLoadGameFileNL_Click(object sender, EventArgs e)
        {
            if(cmbGameNL.SelectedIndex < 0)
            {
                MessageBox.Show("Please select game to continue!");
            }
            else
            {
                uploadFile();
            }
        }
        private void btnLoadGameFileHB_Click(object sender, EventArgs e)
        {
            if (cmbGameHB.SelectedIndex < 0)
            {
                MessageBox.Show("Please select game to continue!");
            }
            else
            {
                uploadFile();
            }
        }
        private void uploadFile()
        {
            var filePath = string.Empty;

            using (OpenFileDialog openFileDialog = new OpenFileDialog())
            {
                openFileDialog.InitialDirectory = Directory.GetCurrentDirectory();
                openFileDialog.Filter = "txt files (*.txt)|*.txt";
                openFileDialog.FilterIndex = 2;
                openFileDialog.RestoreDirectory = true;
                if (openFileDialog.ShowDialog() == DialogResult.OK)
                {
                    filePath = openFileDialog.FileName;
                    File.Copy(filePath, gameFile, true);
                    MessageBox.Show("File uploaded successfully!", "nlGameBot");
                }
            }
        }


        public void setStatus(string status)
        {
            toolStripStatusLabel1.Text = status;
        }

        [Obsolete]
        private void btnRemoveSavedTicketsNL_Click(object sender, EventArgs e)
        {
            DialogResult dialogResult = MessageBox.Show("Are you sure! you wanna remove all your current saved tickets?", "Warning", MessageBoxButtons.YesNo);
            if (dialogResult == DialogResult.Yes)
            {
                myNLGames.myMobileNo = txtMobileNoNL.Text;
                myNLGames.myPassword = txtPasswordHB.Text;
                myNLGames.myWebsiteUrl = cmbGameWebsiteWager.Text;
                myNLGames.removeAllTickets();
            }
        }

        private void btnRemoveTicketsSapa_Click(object sender, EventArgs e)
        {
        }

        private void btnDeletedSelectedReceiptsNL_Click(object sender, EventArgs e)
        {
            deleteSelectedItemsInList(listViewNL, receiptDir + @"\nlReceipt");
            
        }
        private void btnDeleteSelectedReceiptsHB_Click(object sender, EventArgs e)
        {
            deleteSelectedItemsInList(listViewHB, receiptDir + @"\hbReceipt");
        }
        private void deleteSelectedItemsInList(ListView list, string path)
        {
            bool chk = false;
            if (list.Items.Count > 0)
            {
                foreach (ListViewItem item in list.Items)
                {
                    if (item.Checked) { chk = true; break; }
                }
            }
            if (chk)
            {
                DialogResult dialogResult = MessageBox.Show("Are you sure! you wanna delete the selected receipts?", "Warning", MessageBoxButtons.YesNo);
                if (dialogResult == DialogResult.Yes)
                {
                    foreach (ListViewItem item in list.Items)
                    {
                        if (item.Checked)
                        {
                            list.Items.Remove(item);
                            File.Delete(path + @"\" + item.Text + ".txt");
                        }
                    }
                }


            }
            else
            {
                MessageBox.Show("Please select any record to delete!");
            }
        }

        private void btnStartWager_Click(object sender, EventArgs e)
        {
            if(cmbGameWebsiteWager.SelectedIndex < 0)
            {
                MessageBox.Show("");
                return;
            }
            if(cmbGameWebsiteWager.SelectedIndex == 0)
            {

            }
            else if(cmbGameWebsiteWager.SelectedIndex == 1)
            {

            }
        }
    }
}

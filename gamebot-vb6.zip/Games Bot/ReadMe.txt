1) Download and Install SeleniumWrapperSetup:
https://gtechinfo.com/downloads/SeleniumWrapperSetup-1.0.23.0.rar

2) Download and overwrite the latest Chrome Driver into SeleniumWrapper folder which is in your Program Files folder or where ever you were installed the SeleniumWrapper. And Chrome Driver must be according to your Chrome's version:
https://chromedriver.chromium.org/downloads

3) Now, Download and Install the latest Bot Setup:
https://gtechinfo.com/downloads/SetupNLGamesBot.zip
